#fichier f2.sql (avec CREATE DATABASE , CREATE TABLE .... )
