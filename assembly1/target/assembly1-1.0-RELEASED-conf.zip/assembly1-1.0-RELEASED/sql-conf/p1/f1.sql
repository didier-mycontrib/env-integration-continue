#fichier f1.sql (avec CREATE DATABASE , CREATE TABLE .... )
